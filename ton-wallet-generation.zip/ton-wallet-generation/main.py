import os
import uuid
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS
from tonsdk.contract.wallet import Wallets, WalletVersionEnum
from supabase_client import wallet_storage

app = Flask(__name__)
CORS(app)

# Configuration
# Note: Make sure to set these environment variables in your deployment
# SUPABASE_URL: Your Supabase project URL
# SUPABASE_KEY: Your Supabase anon/public key

def generate_single_wallet():
    """Generate a single TON wallet and save it to Supabase"""
    try:
        mnemonics, pub_k, priv_k, wallet = Wallets.create(WalletVersionEnum.v4r2, workchain=0)
        wallet_address = wallet.address.to_string(True, True, False)
        
        wallet_data = {
            "id": str(uuid.uuid4()),
            "address": wallet_address,
            "mnemonics": ' '.join(mnemonics),
            "created_at": datetime.now().isoformat(),
            "used": False
        }
        
        # Save to Supabase
        saved_wallet = wallet_storage.create_wallet(wallet_data)
        if not saved_wallet:
            return {"error": "Failed to save wallet to database"}
            
        return saved_wallet
    except Exception as e:
        return {"error": str(e)}

@app.route('/wallets/next', methods=['GET'])
def get_next_wallet():
    """Get next unused wallet - برای استفاده در GenerateTestUserCommand.php"""
    try:
        # Try to get an existing unused wallet
        wallet = wallet_storage.get_next_wallet()
        
        if not wallet:
            # No unused wallets found, generate a new one
            new_wallet = generate_single_wallet()
            if "error" in new_wallet:
                return jsonify({"error": "Failed to generate new wallet"}), 500
                
            return jsonify({
                "success": True,
                "wallet": new_wallet,
                "generated_new": True
            })
        
        # Return the existing unused wallet
        return jsonify({
            "success": True,
            "wallet": wallet,
            "generated_new": False
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/wallets/<wallet_id>/mark-used', methods=['POST'])
def mark_wallet_used(wallet_id):
    """Mark a wallet as used - برای استفاده در GenerateTestUserCommand.php"""
    try:
        # First verify the wallet exists
        wallet = wallet_storage.get_wallet_by_id(wallet_id)
        if not wallet:
            return jsonify({"error": "Wallet not found"}), 404
        
        # Mark as used
        success = wallet_storage.mark_wallet_used(wallet_id)
        
        if success:
            return jsonify({
                "success": True,
                "message": f"Wallet {wallet_id} marked as used"
            })
        else:
            return jsonify({"error": "Failed to update wallet status"}), 500
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "service": "TON Wallet API"
    })

# # این قسمت حذف شده چون لیارا خودش وب سرور را راه‌اندازی می‌کند
if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8000, debug=False)

