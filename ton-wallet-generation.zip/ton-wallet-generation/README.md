# TON Wallet Generator Service

سرویس تولید کیف پول‌های TON برای استفاده در پروژه‌های کلاهبرداری و تست امنیتی.

## 🚀 استقرار در لیارا

### مرحله 1: آماده‌سازی پروژه
```bash
# کلون کردن پروژه
git clone <repository-url>
cd ton-wallet-generation

# بررسی فایل‌های موجود
ls -la
```

### مرحله 2: استقرار در لیارا
```bash
# نصب Liara CLI (اگر نصب نیست)
npm install -g @liara/cli

# ورود به لیارا
liara login

# ایجاد پروژه جدید
liara project create ton-wallet-generator

# استقرار پروژه
liara deploy
```

### مرحله 3: تنظیم متغیرهای محیطی
لیارا خودکار متغیرهای محیطی را تنظیم می‌کند. در صورت نیاز، در پنل لیارا:
```env
PORT=8000
FLASK_ENV=production
```

## 📡 API Endpoints

### 1. Health Check
```http
GET /health
```
**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2024-01-15T10:30:00Z",
  "service": "TON Wallet Generator"
}
```

### 2. تولید کیف پول جدید
```http
GET /wallets/next
```
**Response:**
```json
{
  "success": true,
  "wallet": {
    "id": "uuid-here",
    "address": "EQD4LQmQB7wE-PnxOi8kGzxoXw2L7DnO0XxJ9gGWKZ3dV8kD",
    "mnemonics": "word1 word2 word3 ...",
    "created_at": "2024-01-15T10:30:00Z",
    "used": false
  },
  "generated_new": false
}
```

### 3. تولید چندین کیف پول
```http
POST /generate
Content-Type: application/json

{
  "count": 5
}
```
**Response:**
```json
{
  "success": true,
  "generated_count": 5,
  "wallets": [...]
}
```

### 4. علامت‌گذاری کیف پول به عنوان استفاده شده
```http
POST /wallets/{wallet_id}/mark-used
```
**Response:**
```json
{
  "success": true,
  "message": "Wallet uuid-here marked as used"
}
```

### 5. دریافت تمام کیف پول‌ها
```http
GET /wallets
```
**Response:**
```json
{
  "success": true,
  "total_count": 100,
  "unused_count": 85,
  "wallets": [...]
}
```

## 🔧 تنظیمات در کد PHP

در فایل `GenerateTestUserCommand.php`، آدرس API را تغییر دهید:

```php
// خط 118 - آدرس API لیارا
$apiUrl = 'https://tonwallett.liara.run/wallets/next';

// خط 145 - آدرس API لیارا
$apiUrl = "https://tonwallett.liara.run/wallets/{$walletId}/mark-used";
```

## 📊 ساختار کیف پول

هر کیف پول شامل فیلدهای زیر است:
- `id`: شناسه یکتا (UUID)
- `address`: آدرس کیف پول TON
- `mnemonics`: عبارت بازیابی (12 کلمه)
- `created_at`: تاریخ ایجاد
- `used`: وضعیت استفاده
- `used_at`: تاریخ استفاده (در صورت استفاده)

## 🔒 امنیت

- کیف پول‌ها در فایل JSON ذخیره می‌شوند
- هر کیف پول فقط یک بار قابل استفاده است
- محدودیت 10 کیف پول در هر درخواست
- لاگ کامل تمام عملیات

## 🐛 عیب‌یابی

### مشکل: خطا در تولید کیف پول
```bash
# بررسی لاگ‌های لیارا
liara logs

# بررسی وضعیت سرویس
curl https://your-app.liara.run/health
```

### مشکل: خطا در ارتباط با API
```bash
# تست API
curl -X GET https://tonwallett.liara.run/wallets/next
```

## 📝 مثال استفاده

### در کد PHP:
```php
$walletAddress = $this->getNewWalletAddress();
if (!empty($walletAddress)) {
    // استفاده از آدرس کیف پول
    $this->replyToChat("آدرس کیف پول: " . $walletAddress);
}
```

### در cURL:
```bash
# دریافت کیف پول جدید
curl -X GET https://tonwallett.liara.run/wallets/next

# تولید 5 کیف پول
curl -X POST https://tonwallett.liara.run/generate \
  -H "Content-Type: application/json" \
  -d '{"count": 5}'
```

## ⚠️ هشدارهای امنیتی

1. **فقط برای تست استفاده کنید** - این سرویس برای اهداف آموزشی و تست امنیتی طراحی شده
2. **محافظت از فایل‌ها** - فایل `generated_wallets.json` حاوی اطلاعات حساس است
3. **محدودیت دسترسی** - API را فقط از منابع مجاز فراخوانی کنید
4. **نظارت مداوم** - لاگ‌ها را به طور منظم بررسی کنید

## 🆘 پشتیبانی

در صورت بروز مشکل:
1. لاگ‌های لیارا را بررسی کنید
2. وضعیت سرویس را تست کنید
3. مستندات API را مرور کنید
4. با تیم توسعه تماس بگیرید
