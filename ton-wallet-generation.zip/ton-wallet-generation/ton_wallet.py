import os
import json
import uuid
from datetime import datetime
from flask import Flask, request, jsonify
from flask_cors import CORS
from tonsdk.contract.wallet import Wallets, WalletVersionEnum

app = Flask(__name__)
CORS(app)

# Configuration
WALLET_STORAGE_FILE = "wallets.json"

def load_existing_wallets():
    """Load existing wallets from storage"""
    if os.path.exists(WALLET_STORAGE_FILE):
        try:
            with open(WALLET_STORAGE_FILE, 'r') as f:
                return json.load(f)
        except:
            return []
    return []

def save_wallets_to_storage(wallets):
    """Save wallets to storage"""
    with open(WALLET_STORAGE_FILE, 'w') as f:
        json.dump(wallets, f, indent=2)

def generate_single_wallet():
    """Generate a single TON wallet"""
    try:
        mnemonics, pub_k, priv_k, wallet = Wallets.create(WalletVersionEnum.v4r2, workchain=0)
        wallet_address = wallet.address.to_string(True, True, False)
        
        wallet_data = {
            "id": str(uuid.uuid4()),
            "address": wallet_address,
            "mnemonics": ' '.join(mnemonics),
            "created_at": datetime.now().isoformat(),
            "used": False
        }
        
        return wallet_data
    except Exception as e:
        return {"error": str(e)}

@app.route('/wallets/next', methods=['GET'])
def get_next_wallet():
    """Get next unused wallet - برای استفاده در GenerateTestUserCommand.php"""
    try:
        wallets = load_existing_wallets()
        unused_wallets = [w for w in wallets if not w.get('used', False)]
        
        if not unused_wallets:
            # Generate a new wallet if none available
            new_wallet = generate_single_wallet()
            if "error" in new_wallet:
                return jsonify({"error": "Failed to generate new wallet"}), 500
            
            wallets.append(new_wallet)
            save_wallets_to_storage(wallets)
            return jsonify({
                "success": True,
                "wallet": new_wallet,
                "generated_new": True
            })
        
        # Return the first unused wallet
        wallet = unused_wallets[0]
        return jsonify({
            "success": True,
            "wallet": wallet,
            "generated_new": False
        })
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/wallets/<wallet_id>/mark-used', methods=['POST'])
def mark_wallet_used(wallet_id):
    """Mark a wallet as used - برای استفاده در GenerateTestUserCommand.php"""
    try:
        wallets = load_existing_wallets()
        
        for wallet in wallets:
            if wallet['id'] == wallet_id:
                wallet['used'] = True
                wallet['used_at'] = datetime.now().isoformat()
                save_wallets_to_storage(wallets)
                return jsonify({
                    "success": True,
                    "message": f"Wallet {wallet_id} marked as used"
                })
        
        return jsonify({"error": "Wallet not found"}), 404
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "service": "TON Wallet API"
    })

# این قسمت حذف شده چون لیارا خودش وب سرور را راه‌اندازی می‌کند
# if __name__ == "__main__":
#     app.run(host='0.0.0.0', port=8000, debug=False)

