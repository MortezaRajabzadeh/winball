import json
import os
from datetime import datetime
from supabase_client import wallet_storage

def migrate_wallets():
    """Migrate wallets from local JSON file to Supabase"""
    json_file = "wallets.json"
    
    if not os.path.exists(json_file):
        print(f"No {json_file} file found. Nothing to migrate.")
        return
    
    try:
        # Load existing wallets from JSON
        with open(json_file, 'r') as f:
            wallets = json.load(f)
        
        if not isinstance(wallets, list):
            print("Invalid wallet data format in JSON file.")
            return
        
        print(f"Found {len(wallets)} wallets to migrate...")
        
        # Migrate each wallet to Supabase
        migrated_count = 0
        for wallet in wallets:
            try:
                # Check if wallet already exists in Supabase
                existing = wallet_storage.get_wallet_by_id(wallet['id'])
                if existing:
                    print(f"Wallet {wallet['id']} already exists in Supabase. Skipping...")
                    continue
                
                # Convert created_at string to ISO format if needed
                if 'created_at' in wallet and isinstance(wallet['created_at'], str):
                    try:
                        # Try to parse the date string to ensure it's in the correct format
                        datetime.fromisoformat(wallet['created_at'].replace('Z', '+00:00'))
                    except ValueError:
                        # If parsing fails, use the current time
                        wallet['created_at'] = datetime.now().isoformat()
                
                # Add the wallet to Supabase
                result = wallet_storage.create_wallet(wallet)
                if result:
                    migrated_count += 1
                    print(f"Migrated wallet {wallet['id']} to Supabase")
                else:
                    print(f"Failed to migrate wallet {wallet['id']}")
                    
            except Exception as e:
                print(f"Error migrating wallet {wallet.get('id', 'unknown')}: {str(e)}")
        
        print(f"\nMigration complete. Successfully migrated {migrated_count} out of {len(wallets)} wallets to Supabase.")
        
    except Exception as e:
        print(f"Error during migration: {str(e)}")

if __name__ == "__main__":
    print("Starting wallet migration to Supabase...")
    migrate_wallets()
