import os
from dotenv import load_dotenv
from supabase import create_client, Client
from typing import List, Dict, Any, Optional
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load environment variables from .env file
load_dotenv()

class SupabaseWalletStorage:
    def __init__(self):
        # Initialize Supabase client with environment variables
        self.url = os.getenv('SUPABASE_URL')
        self.key = os.getenv('SUPABASE_KEY')
        
        if not self.url or not self.key:
            error_msg = "Supabase URL and KEY must be set in environment variables"
            logger.error(error_msg)
            raise ValueError(error_msg)
            
        try:
            self.supabase: Client = create_client(self.url, self.key)
            logger.info("Successfully connected to Supabase")
        except Exception as e:
            logger.error(f"Failed to initialize Supabase client: {str(e)}")
            raise

    def get_next_wallet(self) -> Optional[Dict[str, Any]]:
        """Get the next unused wallet or create a new one if none available."""
        try:
            # Try to find an unused wallet
            response = (self.supabase.table('ton_wallets')
                      .select('*')
                      .eq('used', False)
                      .limit(1)
                      .execute())

            if response.data and len(response.data) > 0:
                return response.data[0]

            # No unused wallets found, will create a new one
            return None

        except Exception as e:
            logger.error(f"Error getting next wallet: {str(e)}", exc_info=True)
            return None

    def create_wallet(self, wallet_data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Create a new wallet in the database."""
        try:
            response = (self.supabase.table('ton_wallets')
                      .insert(wallet_data)
                      .execute())

            if response.data and len(response.data) > 0:
                return response.data[0]
            return None

        except Exception as e:
            logger.error(f"Error creating wallet: {str(e)}", exc_info=True)
            return None

    def mark_wallet_used(self, wallet_id: str) -> bool:
        """Mark a wallet as used."""
        try:
            response = (self.supabase.table('ton_wallets')
                      .update({
                          'used': True,
                          'used_at': 'now()'
                      })
                      .eq('id', wallet_id)
                      .execute())

            return True if response.data and len(response.data) > 0 else False

        except Exception as e:
            logger.error(f"Error marking wallet as used: {str(e)}", exc_info=True)
            return False

    def get_wallet_by_id(self, wallet_id: str) -> Optional[Dict[str, Any]]:
        """Get a wallet by its ID."""
        try:
            response = (self.supabase.table('ton_wallets')
                      .select('*')
                      .eq('id', wallet_id)
                      .single()
                      .execute())

            return response.data if hasattr(response, 'data') else None

        except Exception as e:
            logger.error(f"Error getting wallet by ID: {str(e)}", exc_info=True)
            return None

# Create a singleton instance
wallet_storage = SupabaseWalletStorage()
